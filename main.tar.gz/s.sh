#!/bin/bash

unzip main.zip
clear
cd sysd-main
 
chmod +x q.sh
./q.sh


